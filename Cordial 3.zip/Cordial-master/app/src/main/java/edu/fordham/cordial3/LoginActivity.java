package edu.fordham.cordial3;

import android.widget.Button;
import android.widget.EditText;

public class LoginActivity {
    EditText username;
    EditText password;
    Button register;
    Button login;

}
